package comp110;

/*
 * Author: <Seth Little>
 *
 * ONYEN: <sethl>
 *
 * UNC Honor Pledge: I certify that no unauthorized assistance has been 
 * received or given in the completion of this work. I collaborated with
 * no one other than official COMP110 UTAs on this code.
 */
public class DankMemeApp {

	public static void main(String[] args) {

		// Your code will go below this line. You can delete this line and the
		// next.
		// These two lines are "comments" because they start with two slashes.

		MemePhoto meme = new MemePhoto();
		meme.setImageUrl("http://wallpaper-gallery.net/images/michael-jordan/michael-jordan-6.jpg");
		meme.setTopText("when");
		meme.setBottomText("duke loses");

	}

}